public class Blatt8_Aufgabe1 {

    public static int diff(int m, int n){

        if(n > m){
            return C_0_0();
        }
        else if(n > 0){
            return pred(diff(m, minus(n,1)));
        }
        else{
            return m;
        }
    }

    public static int absdiff(int m, int n){

        return add(diff(P_2_2(m,n),P_2_1(m,n)),diff(m,n));
    }

    public static int odd(int n){

        if(n == 0){
            return C_0_0();
        }else if(n == 1){
            return C_0_1();
        }else{
            return odd(minus(n,2));
        }
    }

    public static int min(int m, int n){
        return diff(add(m, n), maximum(m,n));
    }

    static int C_0_1(){
        return 1;
    }

    // ===================
    // Vorg�ngerFunktionen
    // ===================

    static int pred(int n) {
        if (n == 0)
            return 0;
        else
            return P_2_1(n - 1, pred(n - 1));
    }

    // ===================
    // Addition
    // ===================

    static int add(int n, int m) {
        if (n == 0)
            return P_1_1(m);
        else
            return succ(P_3_3(n-1, m, add(n - 1, m)));
    }


    // ===================
    // minus
    // ===================
    static int minus(int n, int m) {
        if (m == 0)
            return n;
        else
            return pred(P_3_3(m-1, n, minus(n, m-1)));
    }

    // Beachte: die primitive Rekursion erfolgt im zweiten Argument m.S


    // ===================
    // Summe 0 + 1 + 2 + 3 + 4 + 5 ...
    // ===================

    static int sum(int n) {
        if (n == 0)
            return C_0_0();
        else
            return add(succ(P_2_1(n-1, sum(n-1))), P_2_2(n-1, sum(n-1)));
    }

    // ===================
    // Maximum
    // ===================

    static int maximum(int m, int n) {
        return add(minus(m,n),n);
    }

    // ===================
    // Ausgew�hlte konstante Funktionen
    // ===================

    static int C_0_0() {
        return 0;
    }

    static int C_0_5() {
        return 5;
    }

    // ===================
    // Nachfolger-Funktion
    // ===================

    static int succ(int n) {
        return n + 1;
    }

    // ===================
    // Ausgew�hlte Projektionen
    // ===================
    static int P_1_1(int x1) {
        return x1;
    }

    static int P_2_1(int x1, int x2) {
        return x1;
    }

    static int P_2_2(int x1, int x2) {
        return x2;
    }

    static int P_3_1(int x1, int x2, int x3) {
        return x1;
    }

    static int P_3_2(int x1, int x2, int x3) {
        return x2;
    }

    static int P_3_3(int x1, int x2, int x3) {
        return x3;
    }
}
