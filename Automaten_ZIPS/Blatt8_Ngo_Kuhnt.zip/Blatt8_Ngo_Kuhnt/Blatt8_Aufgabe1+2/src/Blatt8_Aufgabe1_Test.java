import org.junit.Assert;
import org.junit.Test;

public class Blatt8_Aufgabe1_Test {

    @Test
    public void diffTest() {
        Assert.assertEquals(0, Blatt8_Aufgabe1.diff(5,10));
        Assert.assertEquals(1, Blatt8_Aufgabe1.diff(3,2));
        Assert.assertEquals(3, Blatt8_Aufgabe1.diff(6,3));
    }

    @Test
    public void absdiffTest() {
        Assert.assertEquals(5, Blatt8_Aufgabe1.absdiff(5,10));
        Assert.assertEquals(1, Blatt8_Aufgabe1.absdiff(2,1));
        Assert.assertEquals(3, Blatt8_Aufgabe1.absdiff(6,3));
    }

    @Test
    public void oddTest() {
        Assert.assertEquals(1, Blatt8_Aufgabe1.odd(5));
        Assert.assertEquals(0, Blatt8_Aufgabe1.odd(2));
        Assert.assertEquals(0, Blatt8_Aufgabe1.odd(6));
    }

    @Test
    public void minTest() {
        Assert.assertEquals(2, Blatt8_Aufgabe1.min(2,5));
        Assert.assertEquals(5, Blatt8_Aufgabe1.min(6,5));
        Assert.assertEquals(1, Blatt8_Aufgabe1.min(1, 4));
    }
}
