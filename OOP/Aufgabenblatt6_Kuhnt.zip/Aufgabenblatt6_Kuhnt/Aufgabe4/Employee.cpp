#include "Employee.h"

Employee::Employee(int id, std::string lastname, std::string firstname): Person(id, lastname, firstname){
    
}

double Employee::salary(){
    return 0;
}