template <typename T>
class Iterator{
    private:
        int offset;
        const ArrayList& list;
    public:
        typedef typename std::vector<T>::iterator iter_type;
        Iterator(U *arraylist, bool reverse = false) : list(arraylist) {
            offset = list[0];
        }

        void First() {
            offset = list[0];
         }

        void Next() {
            offset++;
        }

        bool IsDone() {
            return (offset == list.getSize());
        }

        iter_type Current() {
            return offset;
        }
}